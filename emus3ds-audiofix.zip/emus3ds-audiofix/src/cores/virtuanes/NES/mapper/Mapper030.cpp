//////////////////////////////////////////////////////////////////////////
// Mapper030 UNROM 512 (homebrew)                                       //
//  $8000-$FFFF : bits 0-4 = 16K PRG bank at $8000 ($C000 fixed last)   //
//                bits 5-6 = 8K CHR-RAM bank                            //
//                bit 7    = one-screen mirroring select (only when     //
//                           the header marks 4-screen without vertical)//
// Self-flash saving is not emulated.                                   //
//////////////////////////////////////////////////////////////////////////
void	Mapper030::Reset()
{
	SetPROM_32K_Bank( 0, 1, PROM_8K_SIZE-2, PROM_8K_SIZE-1 );
	SetCRAM_8K_Bank( 0 );

	// Header: 4-screen flag without the vertical flag = switchable one-screen.
	bOneScreen = nes->rom->Is4SCREEN() && !nes->rom->IsVMIRROR();
	if( bOneScreen )
		SetVRAM_Mirror( VRAM_MIRROR4L );
}

void	Mapper030::Write( WORD addr, BYTE data )
{
	INT	bank = data & 0x1F;
	if( PROM_16K_SIZE > 0 )
		bank %= PROM_16K_SIZE;

	SetPROM_16K_Bank( 4, bank );
	SetCRAM_8K_Bank( (data>>5) & 0x03 );

	if( bOneScreen ) {
		if( data & 0x80 ) SetVRAM_Mirror( VRAM_MIRROR4H );
		else		  SetVRAM_Mirror( VRAM_MIRROR4L );
	}
}
