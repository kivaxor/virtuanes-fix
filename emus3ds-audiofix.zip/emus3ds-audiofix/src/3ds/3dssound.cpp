
#include <stdio.h>
#include <cstring>

#include "3dsemu.h"
#include "3dsgpu.h"
#include "3dssound.h"
#include "3dsopt.h"
#include "3dsemu.h"
#include "3dsmain.h"
#include "3dsasync.h"

#include "3dsinterface.h"

#define LEFT_CHANNEL        10
#define RIGHT_CHANNEL       11


SSND3DS snd3DS;

int debugSoundCounter = 0;

int csndTicksPerSecond = 267951600;           // use this for 44100 Khz
int snd3dsSampleRate = 44100;
int snd3dsSamplesPerLoop = 735;
bool snd3dsIsStereo = true;
bool snd3dsSpawnMixingThread = true;
int snd3dsMinLoopBuffer = 1;
int snd3dsMaxLoopBuffer = 2;

#define SAMPLEBUFFER_SIZE 44100


//---------------------------------------------------------
// Computes the truncated number of samples per loop by
// dividing the the ideal sample rate by the total
// number of loops to be executed per second. 
//
// Usually loopsPerSecond is the frame rate. If you want
// to generate samples twice per frame, then this value
// will be the frame rate x 2.
//---------------------------------------------------------
int snd3dsComputeSamplesPerLoop(int idealSampleRate, int loopsPerSecond)
{
    return idealSampleRate / loopsPerSecond;
}


//---------------------------------------------------------
// Computes the final sample rate by taking the 
// samples generate per loop multiplying by the 
// number of loops in a second.
//---------------------------------------------------------
int snd3dsComputeSampleRate(int idealSampleRate, int loopsPerSecond)
{
	return (idealSampleRate / loopsPerSecond) * loopsPerSecond;
}


//---------------------------------------------------------
// Gets the current playing sample position.
//
// The problem is that the existing CSND library
// is unable to provide the actual playing sample
// position from the hardware. So we have to compute
// this manually. 
//
// But computing it this way may cause skews in sound
// generation over time, so the csndTicksPerSecond
// has to be correct to minimize skewing.
//---------------------------------------------------------
u64 snd3dsGetSamplePosition() {
	u64 delta = (svcGetSystemTick() - snd3DS.startTick);
	u64 samplePosition = delta * snd3dsSampleRate / csndTicksPerSecond;

    snd3DS.samplePosition = samplePosition;
	return samplePosition;
}

int blockCount = 0;


//---------------------------------------------------------
// NDSP (DSP) audio backend.
//
// CSND is a legacy service that most 3DS emulators
// (Citra / Azahar, including the Android builds) do not
// emulate, which results in no sound at all. NDSP works on
// both real hardware (needs dspfirm.cdc) and emulators,
// so it is preferred, and CSND is only used as a fallback.
//---------------------------------------------------------
#define NDSP_NUM_BUFFERS    6
#define NDSP_CHANNEL        0

static ndspWaveBuf  ndspWaveBufs[NDSP_NUM_BUFFERS];
static s16          *ndspData = NULL;
static int          ndspDataSamples = 0;     // capacity: samples per buffer
static int          ndspNextBuf = 0;

static void snd3dsNdspFreeBuffers()
{
    if (ndspData)
    {
        linearFree(ndspData);
        ndspData = NULL;
    }
    ndspDataSamples = 0;
}

static void snd3dsNdspMixSamples()
{
    if (!snd3DS.isPlaying || !ndspData)
        return;

    ndspWaveBuf *wb = &ndspWaveBufs[ndspNextBuf];
    if (wb->status == NDSP_WBUF_QUEUED || wb->status == NDSP_WBUF_PLAYING)
    {
        // All buffers are still full. Wait for the DSP to consume one.
        svcSleepThread(1000000);
        return;
    }

    int channels = snd3dsIsStereo ? 2 : 1;
    int n = snd3dsSamplesPerLoop;
    if (n > ndspDataSamples)
        n = ndspDataSamples;

    impl3dsGenerateSoundSamples(snd3dsSamplesPerLoop);
    impl3dsOutputSoundSamples(snd3dsSamplesPerLoop, snd3DS.leftBuffer, snd3DS.rightBuffer);

    s16 *dst = ndspData + ndspNextBuf * ndspDataSamples * 2;
    if (snd3dsIsStereo)
    {
        for (int i = 0; i < n; i++)
        {
            dst[i * 2] = snd3DS.leftBuffer[i];
            dst[i * 2 + 1] = snd3DS.rightBuffer[i];
        }
    }
    else
    {
        for (int i = 0; i < n; i++)
            dst[i] = snd3DS.leftBuffer[i];
    }
    DSP_FlushDataCache(dst, n * channels * sizeof(s16));

    memset(wb, 0, sizeof(ndspWaveBuf));
    wb->data_vaddr = dst;
    wb->nsamples = n;
    wb->looping = false;
    wb->status = NDSP_WBUF_FREE;
    ndspChnWaveBufAdd(NDSP_CHANNEL, wb);

    ndspNextBuf = (ndspNextBuf + 1) % NDSP_NUM_BUFFERS;
}


//---------------------------------------------------------
// Mix the samples.
//
// This is usually called from within 3dssound.cpp.
// It should only be called externall from other 
// files when running in Citra.
//---------------------------------------------------------
void snd3dsMixSamples()
{
    #define MIN_FORWARD_BLOCKS          8
    #define MAX_FORWARD_BLOCKS          16

    if (snd3DS.audioType == 2)
    {
        snd3dsNdspMixSamples();
        return;
    }

    t3dsStartTiming(44, "Mix");
    bool generateSound = false;
    if (snd3DS.isPlaying)
    {
        impl3dsGenerateSoundSamples(snd3dsSamplesPerLoop);
        generateSound = true;
    }
    t3dsEndTiming(44);

    t3dsStartTiming(41, "Mix-Timing");
    long generateAtSamplePosition = 0;
    while (true)
    {
        s64 nowSamplePosition = snd3dsGetSamplePosition();
        s64 deltaTimeAhead = snd3DS.upToSamplePosition - nowSamplePosition;
        long blocksAhead = deltaTimeAhead / snd3dsSamplesPerLoop;

        if (blocksAhead < snd3dsMinLoopBuffer)
        {
            // buffer is about to underrun.
            //
            generateAtSamplePosition =
                ((u64)((nowSamplePosition + snd3dsSamplesPerLoop - 1) / snd3dsSamplesPerLoop)) * snd3dsSamplesPerLoop +
                MIN_FORWARD_BLOCKS * snd3dsSamplesPerLoop;
            break;
        }
        else if (blocksAhead < snd3dsMaxLoopBuffer)
        {
            // play head is still within acceptable range.
            // so we place the generated samples at where
            // we left off previously
            //
            generateAtSamplePosition = snd3DS.upToSamplePosition;
            break;
        }

        // blocksAhead >= MAX_FORWARD_BLOCKS
        // although we've already mixed the previous block,
        // we are too ahead of time, so let's wait for 0.1 millisecs.
        //
        // That may help to save some battery.
        //
        svcSleepThread(100000);
        //async3dsExecuteTasks();
    }

    snd3DS.startSamplePosition = generateAtSamplePosition;
    snd3DS.upToSamplePosition = generateAtSamplePosition + snd3dsSamplesPerLoop;
    t3dsEndTiming(41);

    t3dsStartTiming(42, "Mix-ApplyMstVol");
    int p = generateAtSamplePosition % snd3dsSampleRate;

    if (snd3DS.audioType==1)
    {
        if (generateSound)
        {
            impl3dsOutputSoundSamples(snd3dsSamplesPerLoop, &snd3DS.leftBuffer[p], &snd3DS.rightBuffer[p]);
        }
        else
        {
            for (int i = 0; i < snd3dsSamplesPerLoop; i++)
            {
                snd3DS.leftBuffer[p + i] = 0;
                snd3DS.rightBuffer[p + i] = 0;
            }
        }
    }
    t3dsEndTiming(42);

    // Now that we have the samples, we have to copy it back into our buffers
    // for the 3DS to playback
    //
    t3dsStartTiming(43, "Mix-Flush");
    blockCount++;

    // Doing GSPGPU_FlushDataCache may cause race conditions with
    // the battery check (and other stuff?) on the main thread.
    // causing the whole emulator to freeze. 
    //
    // So we only flush data cache if the snd3DS.isPlaying is true.
    //
    if (blockCount % MIN_FORWARD_BLOCKS == 0 && snd3DS.isPlaying)
        CSND_FlushDataCache(snd3DS.fullBuffers, SAMPLEBUFFER_SIZE * 2 * 2);
    t3dsEndTiming(43);
}


//---------------------------------------------------------
// This function is the entry point to the sound mixing
// thread.
//---------------------------------------------------------
void snd3dsMixingThread(void *p)
{
    snd3DS.upToSamplePosition = snd3dsGetSamplePosition();
    snd3DS.startSamplePosition = snd3DS.upToSamplePosition;
    //svcExitThread();
    //return;

    while (!snd3DS.terminateMixingThread)
    {
        if (!emulator.isReal3DS)
            svcSleepThread(100000 * 1);

        if (snd3DS.isPlaying)
            snd3dsMixSamples();
        else
            svcSleepThread(1000000);
    }
    snd3DS.terminateMixingThread = true;
    // return from the libctru thread entry (do NOT call svcExitThread)
}


//---------------------------------------------------------
// Triggers the CSND to play the sound from the
// buffers.
//---------------------------------------------------------
Result snd3dsPlaySound(int chn, u32 flags, u32 sampleRate, float vol, float pan, void* data0, void* data1, u32 size)
{
	u32 paddr0 = 0, paddr1 = 0;

	int encoding = (flags >> 12) & 3;
	int loopMode = (flags >> 10) & 3;

	if (!loopMode) flags |= SOUND_ONE_SHOT;

	if (encoding != CSND_ENCODING_PSG)
	{
		if (data0) paddr0 = osConvertVirtToPhys(data0);
		if (data1) paddr1 = osConvertVirtToPhys(data1);

		if (data0 && encoding == CSND_ENCODING_ADPCM)
		{
			int adpcmSample = ((s16*)data0)[-2];
			int adpcmIndex = ((u8*)data0)[-2];
			CSND_SetAdpcmState(chn, 0, adpcmSample, adpcmIndex);
		}
	}

	u32 timer = CSND_TIMER(sampleRate);

	if (timer < 0x0042) timer = 0x0042;
	else if (timer > 0xFFFF) timer = 0xFFFF;
	flags &= ~0xFFFF001F;
	flags |= SOUND_ENABLE | SOUND_CHANNEL(chn) | (timer << 16);

    // compute the ticks per second.
    csndTicksPerSecond = (uint64)timer * 4 * sampleRate;

	u32 volumes = CSND_VOL(vol, pan);
	CSND_SetChnRegs(flags, paddr0, paddr1, size, volumes, volumes);

	if (loopMode == CSND_LOOPMODE_NORMAL && paddr1 > paddr0)
	{
		// Now that the first block is playing, configure the size of the subsequent blocks
		size -= paddr1 - paddr0;
		CSND_SetBlock(chn, 1, paddr1, size);
	}
    CSND_SetPlayState(chn, 1);
    return 0;
}


//---------------------------------------------------------
// Start playing the samples.
//---------------------------------------------------------
void snd3dsStartPlaying()
{
    if (!snd3DS.isPlaying && snd3DS.audioType == 2)
    {
        // NDSP
        ndspChnWaveBufClear(NDSP_CHANNEL);
        memset(ndspWaveBufs, 0, sizeof(ndspWaveBufs));
        ndspNextBuf = 0;

        if (!ndspData || ndspDataSamples < snd3dsSamplesPerLoop)
        {
            snd3dsNdspFreeBuffers();
            ndspDataSamples = snd3dsSamplesPerLoop;
            ndspData = (s16 *)linearAlloc(NDSP_NUM_BUFFERS * ndspDataSamples * 2 * sizeof(s16));
            if (!ndspData)
            {
                ndspDataSamples = 0;
                return;
            }
            memset(ndspData, 0, NDSP_NUM_BUFFERS * ndspDataSamples * 2 * sizeof(s16));
        }

        ndspChnReset(NDSP_CHANNEL);
        ndspChnSetInterp(NDSP_CHANNEL, NDSP_INTERP_LINEAR);
        ndspChnSetRate(NDSP_CHANNEL, (float)snd3dsSampleRate);
        ndspChnSetFormat(NDSP_CHANNEL, snd3dsIsStereo ? NDSP_FORMAT_STEREO_PCM16 : NDSP_FORMAT_MONO_PCM16);

        float mix[12];
        memset(mix, 0, sizeof(mix));
        mix[0] = 1.0f;      // front left
        mix[1] = 1.0f;      // front right
        ndspChnSetMix(NDSP_CHANNEL, mix);

        snd3DS.startTick = svcGetSystemTick();
        snd3DS.upToSamplePosition = 0;
        snd3DS.isPlaying = true;
    }
    else if (!snd3DS.isPlaying)
    {
        for (int i = 0; i < SAMPLEBUFFER_SIZE; i++)
        {
            snd3DS.leftBuffer[i] = 0;
            snd3DS.rightBuffer[i] = 0;
        }
        CSND_FlushDataCache(snd3DS.fullBuffers, SAMPLEBUFFER_SIZE * 2 * 2);
        
        // CSND
        // Fix: Copied libctru's csndPlaySound and modified it so that it will
        // not play immediately upon calling. This seems to solve the left
        // channel louder than right channel problem.
        //
        if (snd3dsIsStereo)
        {
            snd3dsPlaySound(LEFT_CHANNEL, SOUND_REPEAT | SOUND_FORMAT_16BIT, snd3dsSampleRate, 1.0f, -1.0f, (u32*)snd3DS.leftBuffer, (u32*)snd3DS.leftBuffer, snd3dsSampleRate * 2);
            snd3dsPlaySound(RIGHT_CHANNEL, SOUND_REPEAT | SOUND_FORMAT_16BIT, snd3dsSampleRate, 1.0f, 1.0f, (u32*)snd3DS.rightBuffer, (u32*)snd3DS.rightBuffer, snd3dsSampleRate * 2);
        }
        else
        {
            snd3dsPlaySound(LEFT_CHANNEL, SOUND_REPEAT | SOUND_FORMAT_16BIT, snd3dsSampleRate, 1.0f, 0, (u32*)snd3DS.leftBuffer, (u32*)snd3DS.leftBuffer, snd3dsSampleRate * 2);
        }

        // Flush CSND command buffers
        csndExecCmds(true);
        snd3DS.startTick = svcGetSystemTick();

        // Fix for race condition for 64-bit access in the sound thread.
        snd3DS.upToSamplePosition = snd3dsGetSamplePosition();  
        snd3DS.isPlaying = true;
    }
}


//---------------------------------------------------------
// Stop playing the samples.
//---------------------------------------------------------
void snd3dsStopPlaying()
{
    if (snd3DS.isPlaying)
    {
        snd3DS.isPlaying = false;
        if (snd3DS.audioType == 2)
        {
            ndspChnWaveBufClear(NDSP_CHANNEL);
        }
        else
        {
            CSND_SetPlayState(LEFT_CHANNEL, 0);
            CSND_SetPlayState(RIGHT_CHANNEL, 0);

            // Flush CSND command buffers
            csndExecCmds(true);
        }
    }
}


//---------------------------------------------------------
// Set the sampling rate.
//
// This function should be called by the 
// impl3dsInitializeCore function. It CANNOT be called
// after the snd3dsInitialize function is called.
//---------------------------------------------------------
void snd3dsSetSampleRate(
    bool isStereo, 
    int idealSampleRate, 
    int loopsPerSecond, 
    bool spawnMixingThread,
    int minLoopBuffer, 
    int maxLoopBuffer)
{
    snd3dsIsStereo = isStereo;
    if (idealSampleRate > 44100)
        idealSampleRate = 44100;
    snd3dsSampleRate = snd3dsComputeSampleRate(idealSampleRate, loopsPerSecond);
    snd3dsSamplesPerLoop = snd3dsComputeSamplesPerLoop(idealSampleRate, loopsPerSecond);
    snd3dsSpawnMixingThread = spawnMixingThread;
    snd3dsMinLoopBuffer = minLoopBuffer;
    snd3dsMaxLoopBuffer = maxLoopBuffer;
}


//---------------------------------------------------------
// Initialize the CSND library.
//---------------------------------------------------------
bool snd3dsInitialize()
{
    snd3DS.isPlaying = false;
    snd3DS.audioType = 0;
    Result ret = 0;

    // Prefer NDSP (works on real hardware with dspfirm.cdc and on
    // emulators such as Citra / Azahar). Fall back to legacy CSND.
    //
    ret = ndspInit();
    if (!R_FAILED(ret))
    {
        printf("Audio: NDSP OK\n");
        ndspSetOutputMode(NDSP_OUTPUT_STEREO);
        snd3DS.audioType = 2;
        ret = 0;
    }
    else
    {
        // Show the error on screen (no log file access needed), pause so it can be read.
        printf("\n*** AUDIO ERROR ***\nndspInit failed: 0x%08lX\nNeed sdmc:/3ds/dspfirm.cdc\n", (unsigned long)ret);
        svcSleepThread(5000000000LL);
        ret = csndInit();
    }

#ifndef EMU_RELEASE
    printf ("Trying to initialize audio, ret = %x\n", ret);
#endif

	if (snd3DS.audioType == 2 || !R_FAILED(ret))
    {
        if (snd3DS.audioType != 2)
            snd3DS.audioType = 1;
#ifndef EMU_RELEASE
        printf ("CSND Initialized\n");
#endif
    }
    else
    {
        printf ("Unable to initialize 3DS CSND service\n");
        return false;
    }

    // Initialize the sound buffers
    //
    snd3DS.fullBuffers = (short *)linearAlloc(SAMPLEBUFFER_SIZE * 2 * 2);
	snd3DS.leftBuffer = &snd3DS.fullBuffers[0];
	snd3DS.rightBuffer = &snd3DS.fullBuffers[SAMPLEBUFFER_SIZE];
    if (snd3DS.fullBuffers)
        memset(snd3DS.fullBuffers, 0, SAMPLEBUFFER_SIZE * 2 * 2);

    if (!snd3DS.fullBuffers)
    {
        printf ("Unable to allocate sound buffers\n");
        snd3dsFinalize();
        return false;
    }

#ifndef EMU_RELEASE
    printf ("snd3dsInit - Allocate L/R buffers\n");
#endif

    // SNES DSP thread
    snd3DS.terminateMixingThread = false;

    snd3DS.mixingThreadHandle = NULL;
    snd3DS.mixingThread = NULL;

    if (emulator.isReal3DS || snd3DS.audioType == 2)
    {
#ifdef LIBCTRU_1_0_0
        aptOpenSession();
        APT_SetAppCpuTimeLimit(30); // enables syscore usage
        aptCloseSession();   
#else
        APT_SetAppCpuTimeLimit(30); // enables syscore usage
#endif

        snd3DS.mixingThreadHandle = NULL;
        
        if (snd3dsSpawnMixingThread)
        {
    #ifndef EMU_RELEASE
            printf ("snd3dsInit - Mix Stack: %x\n", snd3DS.mixingThreadStack);
            printf ("snd3dsInit - Mix ThreadFunc: %x\n", &snd3dsMixingThread);
    #endif
            // Use libctru threadCreate (sets up TLS/reent); a raw svcCreateThread
            // thread crashes as soon as it touches stdio (fopen/printf) or newlib.
            snd3DS.mixingThread = threadCreate(snd3dsMixingThread, 0, 0x8000, 0x18, 1, false);
            if (!snd3DS.mixingThread)
            {
                snd3DS.mixingThread = threadCreate(snd3dsMixingThread, 0, 0x8000, 0x18, -1, false);
            }
            if (!snd3DS.mixingThread)
            {
                printf("Unable to start Mix thread\n");
                snd3dsFinalize();
                return false;
            }
#ifndef EMU_RELEASE
            printf ("snd3dsInit - Create Mix thread %p\n", (void *)snd3DS.mixingThread);
#endif
        }
    }

#ifndef EMU_RELEASE
    printf ("snd3DSInit complete\n");
#endif

	return true;
}


//---------------------------------------------------------
// Finalize the CSND library.
//---------------------------------------------------------
void snd3dsFinalize()
{
     snd3DS.terminateMixingThread = true;

     if (snd3DS.mixingThread)
     {
         // Wait (at most 1 second) for the sound thread to finish,
#ifndef EMU_RELEASE
         printf ("Join mixingThreadHandle\n");
#endif
         threadJoin(snd3DS.mixingThread, 1000ULL * 1000000ULL);
         threadFree(snd3DS.mixingThread);
         snd3DS.mixingThread = NULL;
     }

    if (snd3DS.fullBuffers)  linearFree(snd3DS.fullBuffers);

    if (snd3DS.audioType == 1)
    {
        snd3dsStopPlaying();
        csndExit();
    }
    else if(snd3DS.audioType == 2)
    {
        snd3dsStopPlaying();
        snd3dsNdspFreeBuffers();
        ndspExit();
    }
}
